import pyautogui as py
import time
py.PAUSE = 25
'''
py.press("win")
py.write("chrome")
py.press("enter")

'''x

py.hotkey('ctrl', 't')
time.sleep(5)
print(py.position())
py.doubleClick(x=0 , y=1)
   
py.hotkey('win', 'r')
py.press('enter')
py.write('mkdir ')
py.press('enter')
py.write('cd')
py.press('enter')




def nome(x):
    print(x)