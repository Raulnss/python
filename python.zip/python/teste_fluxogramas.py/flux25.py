m = input("sexo: ")
n1 = int(input("altura: "))
if m == "masculino":
    print("o peso seria ",72,7*n1-58)
else:
    print("o peso seria ",62,1*n1-44,7)    