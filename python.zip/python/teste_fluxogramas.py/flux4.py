n1 = int(input("coloque um numero: "))
print("o dobro é: ", n1+n1)