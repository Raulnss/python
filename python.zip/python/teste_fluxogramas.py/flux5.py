n1 = int(input("coloque um numero: "))
print("o quadrado é: ", n1**2)