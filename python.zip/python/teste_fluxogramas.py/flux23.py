n1 = int(input("incira a temperatura: "))
print("a temperatura é: ",(9*n1+160)/5)