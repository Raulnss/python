n1 = int(input("coloque um lado do triangulo: "))
n2 = int(input("coloque o lado inferoir a o ultimo: "))
print("a area é: ",(n1*n2)/2)