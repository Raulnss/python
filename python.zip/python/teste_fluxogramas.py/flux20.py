n1 = int(input("incira um numero: "))
print("o sucessor é: ",n1+1)
print("o antecessor é: ",n1-1)