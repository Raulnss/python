n1 = int(input("incira um numero: "))
n2 = int(input("incira outro numero: "))
print("a divisão é: ",n1/n2)
print("o resto de divisão é: ",n1%n2)