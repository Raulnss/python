n1 = input("nome: ") 
n2 = input("sobrenome: ")
print("você é "  + n1+" "+n2)