n1 = int(input("incira um numero: "))
r=n1%2
if r == 0:
    print("o numero é par")
else:
    print("o numero é impar")     