n1 = int(input("incira um numero: "))
n2 = int(input("incira outro numero: "))
if n1 > n2:
    print("a diferença é: ",n1-n2)
else:
    print("a diferença é: ",n2-n1) 