n1 = input("coloque a cor: ")
if n1 == "marrom":
    print("o preço é R$15,00")
elif n1 == "verde":
    print("o preço é R$20,00")
elif n1 == "azul":
    print("o preço é R$40,00") 
elif n1 == "vermelho":
    print("o preço é R$80,00") 
else:
    print("isso não esta no sistema")              