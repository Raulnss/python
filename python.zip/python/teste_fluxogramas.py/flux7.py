n1 = int(input("coloque o tamanho de um dos lados do quadrado: "))
print("a area é: ",n1**2)
print("o perimetro é: ",n1+n1+n1+n1)