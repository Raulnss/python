n = input("nome: ")
n1 = int(input("data de nascimento: "))
resp=2023-n1
print("você é: ", n+" "+str(resp)+" anos")