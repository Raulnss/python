n1 = int(input("coloque um numero: "))
print("o cubo é: ", n1**3)