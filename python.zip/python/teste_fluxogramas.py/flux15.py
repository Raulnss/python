n1 = int(input("incira uma nota: "))
n2 = int(input("incira outra nota: "))
n3 = int(input("incira outra nota: "))
n4 = int(input("incira outra nota: "))
r=(n1+n2+n3+n4)/4
if r >= 7:
    print("foi aprovado")
else:
    print("foi reprovado")