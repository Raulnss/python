n1 = int(input("coloque um lado do retangulo: "))
n2 = int(input("coloque outro lado: "))
print("a area é: ",n1*n2)
print("o perimetro é: ",n1+n2+n1+n2)