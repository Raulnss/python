n1 = int(input("coloque um numero: "))
print("o sucessor é: ",n1+1)
print("o antecesor é: ",n1-1)