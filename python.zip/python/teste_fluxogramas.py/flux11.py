n1 = int(input("coloque o vaalor em reais: "))
print("você tem: ",n1*5,20)