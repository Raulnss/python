n1 = int(input("incira um numero: "))
n2 = int(input("incira outro numero: "))
n=n1
n1=n2
n2=n
print(n1)
print(n2)