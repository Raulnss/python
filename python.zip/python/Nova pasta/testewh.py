q=0
n1 = int(input("incira um numero: "))
while n1 != 0:
    q=q+n1
    print (str(n1))