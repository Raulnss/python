import pyautogui as py
import time
py.PAUSE = 2
py.press('win')
py.write('opera')
py.press('enter')
py.write('https://www.w3schools.com/python/default.asp')
py.press('enter')